from datetime import datetime
from typing import List


class Shift():

    def __init__(self, title, startDateTime, endDateTime, idealProductionUnitsPerMinute, 
                 breakInMinutes = 60, startAssetStatus = 0):
        super().__init__()
        self.ShiftTitle = title
        self.ShiftStartTime = datetime.strptime(startDateTime, '%Y-%m-%d %H:%M:%S')
        self.ShiftEndTime = datetime.strptime(endDateTime, '%Y-%m-%d %H:%M:%S')
        self.IdealRunRate = idealProductionUnitsPerMinute
        self.StartAssetStatus = startAssetStatus
        self.BreakInMinutes = breakInMinutes

class OEEConfiguration():
    
    def __init__(self, shifts: List[Shift], assetIdColumnName = 'Asset',eventTypeColumnName = 'Type', 
                eventValueColumnName = 'Value',eventTimeColumnName = 'Time', assetStatusEventType = 'Status',
                goodProductionEventType = 'GoodUnits', badProductionEventType = 'BadUnits'):
        super().__init__()
        self.shifts = shifts
        self.assetIdColumnName = assetIdColumnName
        self.eventTypeColumnName = eventTypeColumnName
        self.eventValueColumnName = eventValueColumnName
        self.eventTimeColumnName = eventTimeColumnName
        self.assetStatusEventType = assetStatusEventType
        self.goodProductionEventType = goodProductionEventType
        self.badProductionEventType = badProductionEventType