
def test(data):
    print("testing package")
    print(data)